"""
publish.py
生成した記事HTMLを GitHub にpushし、Beehiiv API でメルマガを配信する。

使い方:
  python publish.py --slug "what-is-a-bitcoin-halving" --title "..." --description "..." --tag "Bitcoin"

環境変数（.env または GitHub Actions secrets に設定）:
  GITHUB_TOKEN      : GitHub Personal Access Token (repo権限)
  GITHUB_OWNER      : GitHubユーザー名
  GITHUB_REPO       : リポジトリ名 (例: chainclarity)
  BEEHIIV_API_KEY   : Beehiiv API Key
  BEEHIIV_PUB_ID    : Beehiiv Publication ID
"""

import os
import sys
import base64
import json
import argparse
import requests
import datetime

# ── GitHub 設定 ──────────────────────────────────────────
GH_TOKEN = os.environ.get("GITHUB_TOKEN", "")
GH_OWNER = os.environ.get("GITHUB_OWNER", "")
GH_REPO  = os.environ.get("GITHUB_REPO", "chainclarity")
GH_API   = "https://api.github.com"

# ── Beehiiv 設定 ─────────────────────────────────────────
BH_API_KEY = os.environ.get("BEEHIIV_API_KEY", "")
BH_PUB_ID  = os.environ.get("BEEHIIV_PUB_ID", "")
BH_API     = "https://api.beehiiv.com/v2"


# ── GitHub: ファイルをpush ────────────────────────────────
def github_push(filepath: str, slug: str) -> bool:
    """
    articles/{slug}.html を GitHub リポジトリに push する。
    ファイルが既に存在する場合は更新（SHAが必要）。
    """
    if not all([GH_TOKEN, GH_OWNER, GH_REPO]):
        print("⚠️  GitHub環境変数が未設定。pushをスキップします。")
        return False

    with open(filepath, "r", encoding="utf-8") as f:
        content = f.read()

    encoded = base64.b64encode(content.encode("utf-8")).decode("utf-8")
    gh_path = f"articles/{slug}.html"
    url = f"{GH_API}/repos/{GH_OWNER}/{GH_REPO}/contents/{gh_path}"
    headers = {
        "Authorization": f"Bearer {GH_TOKEN}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
    }

    # 既存ファイルのSHAを取得（更新時に必要）
    sha = None
    resp = requests.get(url, headers=headers)
    if resp.status_code == 200:
        sha = resp.json().get("sha")

    today = datetime.date.today().isoformat()
    payload = {
        "message": f"feat: add article {slug} [{today}]",
        "content": encoded,
        "branch": "main",
    }
    if sha:
        payload["sha"] = sha

    resp = requests.put(url, headers=headers, json=payload)
    if resp.status_code in (200, 201):
        print(f"✅ GitHub push 完了: {gh_path}")
        return True
    else:
        print(f"❌ GitHub push 失敗: {resp.status_code} {resp.text}")
        return False


# ── Beehiiv: メルマガ下書き作成 → 送信 ──────────────────
def beehiiv_send(slug: str, title: str, description: str, tag: str) -> bool:
    """
    Beehiiv API で新記事のメルマガを作成・送信する。
    記事本文は要約＋リンク形式（full HTMLは不要）。
    """
    if not all([BH_API_KEY, BH_PUB_ID]):
        print("⚠️  Beehiiv環境変数が未設定。メルマガ送信をスキップします。")
        return False

    article_url = f"https://chainclarityblog.com/articles/{slug}.html"

    # メルマガ本文HTML
    email_html = f"""
<div style="font-family: 'DM Sans', sans-serif; max-width: 600px; margin: 0 auto; color: #1a1a2e;">
  <div style="background: #0a0c0f; padding: 24px; border-radius: 8px; margin-bottom: 24px;">
    <p style="color: #00e5a0; font-size: 11px; font-weight: 700; letter-spacing: 0.1em; text-transform: uppercase; margin: 0 0 8px;">
      {tag} · New Article
    </p>
    <h1 style="color: #e8eaed; font-size: 24px; font-weight: 800; line-height: 1.2; margin: 0 0 12px;">
      {title}
    </h1>
    <p style="color: #c8ccd4; font-size: 15px; line-height: 1.6; margin: 0;">
      {description}
    </p>
  </div>

  <p style="font-size: 15px; line-height: 1.7; color: #333;">
    Hey — new article just went up on ChainClarity. Here's the quick version:
  </p>

  <p style="font-size: 15px; line-height: 1.7; color: #333;">
    {description} Read the full explainer below — no jargon, no hype.
  </p>

  <div style="text-align: center; margin: 32px 0;">
    <a href="{article_url}"
       style="background: #00e5a0; color: #0a0c0f; font-weight: 700; font-size: 15px;
              padding: 14px 32px; border-radius: 6px; text-decoration: none; display: inline-block;">
      Read the Full Article →
    </a>
  </div>

  <hr style="border: none; border-top: 1px solid #eee; margin: 32px 0;">
  <p style="font-size: 12px; color: #999; text-align: center;">
    ChainClarity · Educational purposes only · Not financial advice<br>
    <a href="{{{{ unsubscribe_url }}}}" style="color: #999;">Unsubscribe</a>
  </p>
</div>
"""

    headers = {
        "Authorization": f"Bearer {BH_API_KEY}",
        "Content-Type": "application/json",
    }

    # 1. 下書き作成
    create_url = f"{BH_API}/publications/{BH_PUB_ID}/posts"
    payload = {
        "subject": f"📖 {title}",
        "preview_text": description[:90],
        "content": {
            "free": email_html,
        },
        "status": "draft",
        "send_at": None,  # Noneで即時送信対象
    }

    resp = requests.post(create_url, headers=headers, json=payload)
    if resp.status_code not in (200, 201):
        print(f"❌ Beehiiv 下書き作成失敗: {resp.status_code} {resp.text}")
        return False

    post_id = resp.json().get("data", {}).get("id")
    print(f"✅ Beehiiv 下書き作成完了: post_id={post_id}")

    # 2. 送信（confirmで即時配信）
    send_url = f"{BH_API}/publications/{BH_PUB_ID}/posts/{post_id}/publish"
    send_payload = {"send_at": None}  # 即時配信
    resp = requests.patch(send_url, headers=headers, json=send_payload)

    if resp.status_code in (200, 201):
        print(f"✅ Beehiiv メルマガ送信完了")
        return True
    else:
        print(f"❌ Beehiiv 送信失敗: {resp.status_code} {resp.text}")
        return False


# ── メイン ───────────────────────────────────────────────
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="ChainClarity 記事公開・メルマガ配信")
    parser.add_argument("--slug",        required=True, help="記事スラッグ (例: what-is-a-bitcoin-halving)")
    parser.add_argument("--title",       required=True, help="記事タイトル")
    parser.add_argument("--description", required=True, help="記事の説明文")
    parser.add_argument("--tag",         required=True, help="記事タグ (例: Bitcoin)")
    parser.add_argument("--no-newsletter", action="store_true", help="メルマガ配信をスキップ")
    args = parser.parse_args()

    filepath = f"./articles/{args.slug}.html"
    if not os.path.exists(filepath):
        print(f"❌ ファイルが見つかりません: {filepath}")
        sys.exit(1)

    # GitHub push
    github_ok = github_push(filepath, args.slug)

    # Beehiiv 送信
    if not args.no_newsletter:
        beehiiv_ok = beehiiv_send(args.slug, args.title, args.description, args.tag)
    else:
        beehiiv_ok = True
        print("⏭️  メルマガ送信スキップ")

    # 結果サマリー
    print("\n── 完了サマリー ──")
    print(f"  GitHub  : {'✅' if github_ok else '⚠️ スキップ/失敗'}")
    print(f"  Beehiiv : {'✅' if beehiiv_ok else '⚠️ スキップ/失敗'}")
