# ChainClarity 自動化スクリプト

記事生成 → GitHub push → Netlify自動デプロイ → Beehiivメルマガ配信 を
ワンコマンドで実行するパイプラインです。

## ファイル構成

```
chainclarity-auto/
├── generate_article.py   # Claude APIで記事HTML生成
├── publish.py            # GitHub push + Beehiiv配信
├── run_all.py            # 一括実行（これを使う）
├── .env.example          # 環境変数テンプレート
├── .gitignore
└── .github/
    └── workflows/
        └── weekly.yml    # GitHub Actions 週次自動実行
```

## セットアップ

### 1. 依存関係インストール

```bash
pip install anthropic requests python-dotenv
```

### 2. 環境変数設定

```bash
cp .env.example .env
# .env を編集して各APIキーを入力
```

必要なAPIキー:

| 変数名 | 取得場所 |
|---|---|
| `ANTHROPIC_API_KEY` | https://console.anthropic.com |
| `GITHUB_TOKEN` | GitHub > Settings > Developer settings > Personal access tokens（repo権限） |
| `GITHUB_OWNER` | GitHubのユーザー名 |
| `GITHUB_REPO` | リポジトリ名（例: `chainclarity`） |
| `BEEHIIV_API_KEY` | Beehiiv > Settings > API |
| `BEEHIIV_PUB_ID` | Beehiiv > Settings > Publication（URLのIDを使用） |

### 3. ローカルテスト（APIキーなしでも確認できる）

```bash
# トピックを指定して記事だけ生成（push・メルマガなし）
python generate_article.py --topic "What is a Bitcoin Halving?"

# 全体パイプライン（GitHub・Beehiivは環境変数なければスキップ）
python run_all.py --topic "What is a Bitcoin Halving?"

# メルマガ配信なしで実行
python run_all.py --no-newsletter
```

## GitHub Actions 自動実行

### Netlify × GitHub 連携手順

1. GitHubにリポジトリを作成（例: `chainclarity`）
2. `chainclarity` フォルダの中身をすべてpush
3. Netlify > Sites > "Import from Git" でリポジトリを選択
4. Build command: なし、Publish directory: `/`（ルート）
5. 以降は `main` ブランチへのpushで自動デプロイ

### Secrets 登録

GitHub リポジトリ > Settings > Secrets and variables > Actions に登録:

- `ANTHROPIC_API_KEY`
- `GH_PAT`（push権限付きのPersonal Access Token）
- `BEEHIIV_API_KEY`
- `BEEHIIV_PUB_ID`

### 自動実行スケジュール

`weekly.yml` のデフォルト: **毎週月曜 9:00 AM ET**

変更する場合は `weekly.yml` の cron 式を編集:
```yaml
- cron: "0 14 * * 1"  # UTC 14:00 = ET 9:00 AM（月曜）
```

### 手動実行

GitHub > Actions > "Weekly Article Auto-Publish" > "Run workflow"
トピックを入力するか、空欄でAI自動選定。

## 全体フロー

```
run_all.py 実行
    │
    ├─ generate_article.py
    │      │
    │      ├─ トピック未指定 → Claude APIがトピック自動選定
    │      ├─ Claude APIで記事JSON生成
    │      └─ articles/{slug}.html を保存
    │
    ├─ publish.py → github_push()
    │      └─ GitHub API で articles/{slug}.html をpush
    │             → Netlify が自動デプロイ（Git連携済みの場合）
    │
    └─ publish.py → beehiiv_send()
           └─ Beehiiv API でメルマガ下書き作成 → 即時配信
```
